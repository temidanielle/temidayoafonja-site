FREE FLAGSHIP — 60-MINUTE MAVEN LIGHTNING LESSON
Decide Whether to Stay or Leave Your Job · Wednesday, September 16, 2026
6:00-7:00 PM Central Time · Free

Compiled Friday, August 21, 2026 at 1:37 PM CT
STATUS: CANDIDATE — see GATE STATUS below. Nothing here is labelled FINAL.

------------------------------------------------------------------------
THE THREE FILES YOU DELIVER FROM
------------------------------------------------------------------------
  01_delivery/
    ...FREE_FLAGSHIP_60MIN_v2.0.2_CANDIDATE.pptx     the deck, 33 slides
                                                     26 active, 27-33 hidden
    Capability_Position_Read_Workbook_60MIN_v2.0.1_CANDIDATE.pdf
                                                     8 pages, 68 form fields
    ...SOP_Sept16_2026_60MIN_v2.0.3_CANDIDATE.docx   operational source of truth

The three carry different version numbers on purpose. Each was corrected in a
different pass, and an artifact is only re-versioned when it actually changes:

    deck      v2.0.2   last changed in the v2.0.2 pass
    workbook  v2.0.1   last changed in the v2.0.1 pass, frozen since
    SOP       v2.0.3   last changed in the v2.0.3 pass

Where any document disagrees with another, the SOP's master reconciliation
table governs.

------------------------------------------------------------------------
GATE STATUS
------------------------------------------------------------------------
Promotion from CANDIDATE to FINAL requires all three, in any order:

    Rehearsal 1 - timed content ........................ OUTSTANDING
    Rehearsal 2 - production ........................... OUTSTANDING
    Workbook behaviour test, Adobe Acrobat Reader ...... PASSED
                                        reported Friday, August 21, 2026 CT

The Acrobat result belongs to this build of the workbook. Regenerating the
workbook voids it, because the form and its JavaScript are rebuilt with it.

------------------------------------------------------------------------
CONTENTS
------------------------------------------------------------------------
  01_delivery/     the three files above
  02_previews/     PDF previews of the deck and the SOP
                   The SOP preview IS a LibreOffice Writer export of the .docx,
                   not a reconstruction: 7 pages, portrait / landscape /
                   landscape / portrait x4. The deck preview is a vector render
                   from real shape geometry, NOT a PowerPoint render.
  03_qa/           change log and QA report (121 of 121 checks pass), the
                   correction note, and DEFERRED_CHANGES.md
  04_promotion/    LinkedIn Featured image, contact sheet, mobile legibility
                   preview, QA note. Separate status - see below.
  05_source/       the workbook generator, for regeneration
  06_superseded/   earlier versions, kept for audit. Do not deliver from here.
  MANIFEST.txt     SHA-256 of every file in this archive

------------------------------------------------------------------------
TWO THINGS THAT ARE NOT SETTLED
------------------------------------------------------------------------
1. 04_promotion/ is CANDIDATE on its own terms. The four existing LinkedIn
   Featured images and their generator are not in this repository, so the new
   image could not be verified against them. It was built from the brand
   palette and the typefaces used across this family. Contact-sheet positions
   1, 2 and 4 are labelled empty slots rather than invented artwork.

2. 03_qa/DEFERRED_CHANGES.md holds approved replacement copy for the workbook's
   page 1 Live/Replay block. It is deliberately NOT applied. Do not open the
   workbook solely to apply it - doing so renames the file out of v2.0.1, drags
   the SOP and QA report with it, and voids the Acrobat result above.
