CAPABILITY FORMATION — SEPTEMBER 2 AND SEPTEMBER 16 SESSION PACKAGE
Assembled Sunday, August 23, 2026 at 4:22 AM CT

STATUS: CANDIDATE. Every artifact in this package is CANDIDATE, not FINAL.


WHAT THIS PASS CHANGED

This was a documentation-only correction pass. No deck, no preview of a deck and
no workbook was rebuilt. The September 2 deck v3.3.8, the September 16 deck
v2.0.3, both of their previews and the v2.0.1 workbook carry the same SHA-256
hashes as the previous delivery — they are in 02_unchanged_carried_forward/ so
the folder split reflects what THIS pass touched, not what an earlier one did.

  SOP v2.0.5 -> v2.0.6
    v2.0.5 exported at eight pages, with a final page carrying only a stub of
    section 12 and the footer. v2.0.6 restores the clean seven-page structure:
    page 1 portrait, pages 2 and 3 landscape carrying the reconciliation table
    seven rows then six, pages 4 through 7 portrait. No blank, divider-only,
    transition-only or short spill page; no page under five substantive lines;
    no clipping or table overflow.

    The fix is whitespace and wording, not type size. Default line spacing moved
    from 1.15 to 1.025, heading and divider spacing tightened, and section 12
    condensed by wording while keeping both of its categories and all eight of
    its items. Section headings remain 16pt, subheads 12.5pt, body 9.8pt.

    One accuracy correction: the SOP no longer states that the September 2
    attendee email was sent. That line now reads "Attendee communications
    configured for the September 2 session, with its registration list maintained
    in Maven."

  QA report v2.0.5 -> v2.0.6
    Three statements the v2.0.5 report still carried are removed.

      * The source map naming PowerPoint v2.0.2 as current, and the explanation
        that v2.0.5 changed only the SOP. The map now reads: PowerPoint v2.0.3,
        workbook v2.0.1, SOP v2.0.6, Architecture v1.1 read-only.
      * QA row 34's note, "Both figures appear in speaker notes only." That was
        false and contradicted row 35. Row 34 now tests the slide faces only;
        row 35 continues to test the notes.
      * The claim that the SOP page count was deliberately unpinned. The
        seven-page assertion is restored and pinned.

    Row 72 now names deck v2.0.3, workbook v2.0.1, SOP v2.0.6 and Architecture
    v1.1 read-only explicitly, and additionally asserts that no superseded
    version string survives anywhere in the SOP.


GATE STATUS

  Rehearsal 1 — timed content ................... OUTSTANDING
  Rehearsal 2 — production ...................... OUTSTANDING
  Workbook behaviour test, Adobe Acrobat Reader .. PASSED, owner-run, Aug 21 2026

Promotion to FINAL requires all three. The Acrobat result belongs to this build
of the workbook; regenerating the workbook would void it.


VERIFICATION

  67 of 67 CTA checks pass. Twenty-one of those assert on the corrected
  documentation itself — this README's own package included — so the
  documentation is under test rather than merely describing the work.

  121 of 121 September 16 cross-document checks pass. IDs are unique, sequential
  and in document order, 1 through 121.

  13 of 13 SOP acceptance tests pass against a real LibreOffice Writer export,
  including exactly seven pages, the portrait/landscape/landscape/portrait x4
  orientation sequence, no page under five substantive lines, and no short spill
  page.

  The SOP preview in this package was re-exported from the delivered .docx and
  compared page by page against the shipped file: same page count, same
  orientation on each page, identical text. Byte comparison is not available
  because LibreOffice stamps a creation time into the PDF.


A CAVEAT WORTH READING

The previews are LibreOffice exports. LibreOffice substitutes fonts it does not
have, so its line breaking is indicative of Word and PowerPoint rather than
identical to them. The eight-page export that prompted this pass was reported
from a different LibreOffice installation, which is why the seven-page layout was
given 2.69 inches of slack on page 7 — roughly nineteen body lines — rather than
being tuned to just fit.


NOT OVERWRITTEN

v3.3.6 and v3.3.7 of the September 2 deck, the v2.0.2 September 16 deck, and
SOP v2.0.5 with its preview and QA report all remain in the working history. This
package carries the current version of each artifact only.
