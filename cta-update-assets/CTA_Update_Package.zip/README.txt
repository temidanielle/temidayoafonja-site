CTA UPDATE — BOTH LIGHTNING LESSON DECKS
Compiled Sunday, August 23, 2026 at 3:50 AM CT
STATUS: CANDIDATE. Nothing here is FINAL.

01_corrected_this_pass/
  Sept 2 deck v3.3.8 + its LibreOffice preview
  SOP v2.0.5 + its LibreOffice preview
  QA report v2.0.5
  CTA change log

02_unchanged_carried_forward/
  Sept 16 deck v2.0.3 + its LibreOffice preview — approved, not modified
  Workbook v2.0.1 — frozen, not regenerated

WHAT CHANGED IN THIS PASS
  Sept 2 deck   v3.3.7 -> v3.3.8, SPEAKER NOTES ONLY. Two sentences on slide 15
                called the continuation invitation a "paid invitation"; both now
                read "continuation invitation". The build asserts every slide
                face and every other slide's notes are identical to v3.3.7, and
                that slide count, hidden state and links are unchanged.
  SOP           v2.0.4 -> v2.0.5. New commercial pricing rule; section 12 now
                separates LIVE external assets from genuinely unbuilt work;
                source map names deck v2.0.3, workbook v2.0.1, SOP v2.0.5,
                Architecture v1.1 read-only; Acrobat pass recorded.
  QA report     v2.0.4 -> v2.0.5. Every stale assertion corrected. Rows read
                1-121 in document order, all PASS.

GATE STATUS
  Rehearsal 1 - timed content ........................ OUTSTANDING
  Rehearsal 2 - production ........................... OUTSTANDING
  Workbook behaviour test, Adobe Acrobat Reader ...... PASSED
                                     owner-run, August 21, 2026

  The Acrobat result belongs to this build of the workbook. Regenerating the
  workbook voids it.

VERIFICATION
  CTA suite ................ 59 of 59 pass, including 13 checks that assert on
                             the corrected SOP, QA report and change log
                             themselves.
  Cross-document suite ..... 121 of 121 pass.
  Both decks and the SOP were exported through LibreOffice and inspected.
  LibreOffice is not PowerPoint or Word: no claim of application-exact
  pagination or line breaking is made here.

NOT OVERWRITTEN
  v3.3.6, v3.3.7 and the v2.0.2 deck all remain in place in the repository.
