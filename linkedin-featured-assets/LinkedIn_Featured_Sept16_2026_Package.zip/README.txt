LinkedIn Featured — September 16, 2026 Maven Lightning Lesson
Status: CANDIDATE

CONTENTS
  linkedin_featured_03_maven_stay_or_leave_1600x900.png   the Featured image
  linkedin_featured_03_maven_stay_or_leave_800x450.png    half-scale export
  linkedin_featured_QA_contact_sheet.png                  four Featured positions
  linkedin_featured_03_mobile_legibility_preview.png      560 / 400 / 320 / 240 px
  LinkedIn_Featured_Sept16_QA_Note.docx                   QA note, read this
  source/                                                 generator + the four fonts

PUBLIC EVENT LINK
  https://maven.com/p/8b3c40/stay-or-leave-live-career-growth-assessment
  Set this as the Featured item's destination. It is deliberately not burned
  into the artwork: a URL small enough to fit is illegible at thumbnail size.

TWO THINGS TO KNOW
  1. The four existing Featured images, their QA contact sheet and their
     generator are not in this repository or its git history. This image was
     built from the brand palette in the site CSS and the three OFL typefaces
     used across the deck family, following the written design direction. It is
     NOT verified against those four images. That is the one gate before FINAL.
     Contact-sheet positions 1, 2 and 4 are therefore labelled empty slots.
     To complete the sheet: put the real files in source/siblings/ and run
     source/build_qa_assets.py.

  2. "50-minute guided assessment + 10-minute Q&A" was left off the event card
     on purpose. It fits on one line, so width was never the issue, but a
     Featured thumbnail renders about 320px wide and that line lands at roughly
     3px on screen. Put it in the Featured item's description text instead.

REGENERATING
  cd source && python3 build_featured.py
  Requires Pillow. The headline auto-fits its column, so changing the copy
  cannot push it into the event card.
