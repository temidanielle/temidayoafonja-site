# -*- coding: utf-8 -*-
"""LinkedIn Featured image — September 16, 2026 Maven Lightning Lesson.

Built in the Capability Formation visual system: cream ground, navy Cormorant
Garamond headline, gold letterspaced eyebrow, small rust divider, navy event
card on the right, generous negative space.

Every block is measured from real font metrics and the headline is auto-fitted
to the column, so text cannot run into the event card whatever the copy says.

NOTE ON PROVENANCE: the four existing Featured images, their QA contact sheet
and their generator are not present in this repository or anywhere in its git
history. This file reproduces the house system from the sources that ARE here —
the site's brand palette and the three OFL typefaces used across the deck
family — and follows the written design direction. It is NOT verified against
those four images.
"""
import os
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "out")
os.makedirs(OUT, exist_ok=True)

NAVY  = (15, 35, 71)
CREAM = (245, 240, 232)
GOLD  = (201, 168, 76)
RUST  = (193, 68, 14)
MUTED = (90, 107, 132)
LIGHT = (184, 197, 217)

W, H = 1600, 900
M = 104                          # outer margin
CARD_W = 468
CARD_X = W - M - CARD_W
GUTTER = 84
COL_R = CARD_X - GUTTER          # left column hard right edge
COLW = COL_R - M

SERIF_B = "CormorantGaramond-Bold.ttf"
SANS    = "DMSans-Regular.ttf"
SANS_B  = "DMSans-Bold.ttf"
LABEL_B = "Montserrat-Bold.ttf"

def F(name, size):
    return ImageFont.truetype(os.path.join(HERE, name), size)

def tw(d, s, font, ls=0.0):
    if not s:
        return 0.0
    return d.textlength(s, font=font) + ls * (len(s) - 1)

def tracked(d, x, y, s, font, fill, ls=0.0):
    """PIL has no tracking, so step per character. Anchored to the ascender."""
    for ch in s:
        d.text((x, y), ch, font=font, fill=fill, anchor="la")
        x += d.textlength(ch, font=font) + ls

def lh(font, factor=1.0):
    a, dsc = font.getmetrics()
    return int((a + dsc) * factor)

def wrap(d, s, font, maxw, ls=0.0):
    words, lines, cur = s.split(), [], ""
    for wd in words:
        t = (cur + " " + wd).strip()
        if tw(d, t, font, ls) > maxw and cur:
            lines.append(cur); cur = wd
        else:
            cur = t
    if cur:
        lines.append(cur)
    return lines

def autofit(d, lines, fontname, maxw, hi=140, lo=64):
    """Largest size at which every line fits the column. Keeps the headline
    dominant without ever letting it reach the event card."""
    for size in range(hi, lo - 1, -2):
        f = F(fontname, size)
        if all(tw(d, l, f) <= maxw for l in lines):
            return f, size
    return F(fontname, lo), lo

# ── copy, exactly as briefed ─────────────────────────────────────────────────
EYEBROW    = "FREE LIVE SESSION"
HEAD       = ["STAY OR LEAVE", "YOUR JOB?"]
SECONDARY  = "LIVE CAREER GROWTH ASSESSMENT"
SUPPORT    = ("Know what your job is building, what you can carry into another "
              "role, and decide your next career move.")
CARD_DATE  = "September 16, 2026"
CARD_TIME  = "6:00 PM CT"
CARD_META  = "60 MINUTES  ·  FREE"
CARD_EXTRA = "50-minute guided assessment + 10-minute Q&A"
FOOTER     = "A CAPABILITY FORMATION LIVE SESSION"

def build():
    img = Image.new("RGB", (W, H), CREAM)
    d = ImageDraw.Draw(img)
    report = {}

    f_eye = F(LABEL_B, 20)
    f_sec = F(SANS_B, 25)
    f_sup = F(SANS, 23)
    f_ft  = F(LABEL_B, 15)
    f_head, head_size = autofit(d, HEAD, SERIF_B, COLW)
    report["headline_pt"] = head_size
    report["headline_w"] = max(tw(d, l, f_head) for l in HEAD)

    sup_lines = wrap(d, SUPPORT, f_sup, COLW)
    report["support_lines"] = len(sup_lines)

    EYE_H  = lh(f_eye)
    HEAD_L = int(head_size * 0.94)          # tight leading for all-caps serif
    SEC_H  = lh(f_sec)
    SUP_L  = 35
    G1, G2, G3, G4 = 40, 44, 40, 30         # eyebrow→head, head→rule, rule→sec, sec→sup
    RULE_H = 5

    block = (EYE_H + G1 + HEAD_L * len(HEAD) + G2 + RULE_H + G3
             + SEC_H + G4 + SUP_L * len(sup_lines))
    top = (H - block) // 2 - 18
    axis = top + block // 2                 # shared optical centre with the card

    y = top
    tracked(d, M, y, EYEBROW, f_eye, GOLD, ls=5.2)
    y += EYE_H + G1
    for ln in HEAD:
        d.text((M, y), ln, font=f_head, fill=NAVY, anchor="la")
        y += HEAD_L
    y += G2
    d.rectangle([M, y, M + 78, y + RULE_H], fill=RUST)
    y += RULE_H + G3
    tracked(d, M, y, SECONDARY, f_sec, NAVY, ls=2.3)
    y += SEC_H + G4
    for ln in sup_lines:
        d.text((M, y), ln, font=f_sup, fill=MUTED, anchor="la")
        y += SUP_L
    report["left_block_bottom"] = y

    tracked(d, M, H - M - 14, FOOTER, f_ft, MUTED, ls=3.0)

    # ── navy event card, measured from its own content ──────────────────────
    f_cd = F(SERIF_B, 50)
    f_ct = F(SERIF_B, 42)
    f_cm = F(LABEL_B, 19)
    f_cx = F(SANS, 16)
    pad = 46
    inner = CARD_W - 2 * pad

    # The optional line is EXCLUDED. It fits the card on one line (362pt inside
    # a 376pt column), so width was never the problem — legibility is. LinkedIn
    # renders a Featured thumbnail around 320px wide, one fifth of this canvas,
    # so 16px type lands at roughly 3px on screen and reads as a grey smudge.
    # The brief rules the line out when it compromises mobile legibility, and it
    # does. It belongs in the Featured item's description text, not in the image.
    ex_lines = wrap(d, CARD_EXTRA, f_cx, inner)
    fits_on_one_line = len(ex_lines) == 1
    thumb_px = 16 * (320 / W)
    include_extra = False
    report["extra_line_fits_on_one_line"] = fits_on_one_line
    report["extra_line_w"] = round(tw(d, CARD_EXTRA, f_cx), 1)
    report["card_inner_w"] = inner
    report["extra_line_thumb_px"] = round(thumb_px, 2)
    report["extra_line_included"] = include_extra

    CD_H, CT_H, CM_H = lh(f_cd), lh(f_ct), lh(f_cm)
    g_a, g_b, g_c = 10, 30, 26
    RULE2 = 3
    ch = pad + CD_H + g_a + CT_H + g_b + RULE2 + g_c + CM_H + pad
    if include_extra:
        ch += 14 + lh(f_cx)
    cy = axis - ch // 2
    d.rectangle([CARD_X, cy, CARD_X + CARD_W, cy + ch], fill=NAVY)

    ty = cy + pad
    d.text((CARD_X + pad, ty), CARD_DATE, font=f_cd, fill=CREAM, anchor="la")
    ty += CD_H + g_a
    d.text((CARD_X + pad, ty), CARD_TIME, font=f_ct, fill=GOLD, anchor="la")
    ty += CT_H + g_b
    d.rectangle([CARD_X + pad, ty, CARD_X + pad + 58, ty + RULE2], fill=GOLD)
    ty += RULE2 + g_c
    tracked(d, CARD_X + pad, ty, CARD_META, f_cm, LIGHT, ls=2.6)
    ty += CM_H
    if include_extra:
        ty += 14
        d.text((CARD_X + pad, ty), ex_lines[0], font=f_cx, fill=LIGHT, anchor="la")

    report["card"] = (CARD_X, cy, CARD_X + CARD_W, cy + ch)
    report["col_right_edge"] = COL_R
    return img, report

if __name__ == "__main__":
    img, rep = build()
    a = os.path.join(OUT, "linkedin_featured_03_maven_stay_or_leave_1600x900.png")
    b = os.path.join(OUT, "linkedin_featured_03_maven_stay_or_leave_800x450.png")
    img.save(a, "PNG")
    img.resize((800, 450), Image.LANCZOS).save(b, "PNG")
    for k, v in rep.items():
        print(f"  {k}: {v}")
    print("\nsaved:", os.path.basename(a), "and", os.path.basename(b))
