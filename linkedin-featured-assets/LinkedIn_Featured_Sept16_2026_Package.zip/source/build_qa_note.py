# -*- coding: utf-8 -*-
"""QA note for the September 16, 2026 LinkedIn Featured image."""
import hashlib, os, sys, subprocess
from datetime import datetime
from zoneinfo import ZoneInfo
from PIL import Image
sys.path.insert(0, "/home/user/temidayoafonja-site/scratchpad/paid-workshop-v5/v531-aug26/src")
from style import *
from docx.shared import Pt as DPt
from docx.oxml.ns import qn as QN
from docx.oxml import OxmlElement as OX

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "out")
NOW = datetime.now(ZoneInfo("America/Chicago"))
STAMP = NOW.strftime("Revised %A, %B %-d, %Y at %-I:%M %p CT")
LINK = "https://maven.com/p/8b3c40/stay-or-leave-live-career-growth-assessment"

def hr(doc):
    p = doc.add_paragraph(); pf = p.paragraph_format
    pf.space_before = DPt(6); pf.space_after = DPt(6); pf.line_spacing = DPt(2)
    pPr = p._p.get_or_add_pPr(); pbdr = OX("w:pBdr"); b = OX("w:bottom")
    b.set(QN("w:val"), "single"); b.set(QN("w:sz"), "6")
    b.set(QN("w:space"), "1"); b.set(QN("w:color"), "B8C5D9")
    pbdr.append(b); pPr.append(pbdr); return p

def tidy(t):
    trPr = t.rows[0]._tr.get_or_add_trPr()
    th = OX("w:tblHeader"); th.set(QN("w:val"), "true"); trPr.append(th)
    for r in t.rows:
        tp = r._tr.get_or_add_trPr()
        cs = OX("w:cantSplit"); cs.set(QN("w:val"), "true"); tp.append(cs)
    return t

def sha(p): return hashlib.sha256(open(p, "rb").read()).hexdigest()

A = os.path.join(OUT, "linkedin_featured_03_maven_stay_or_leave_1600x900.png")
B = os.path.join(OUT, "linkedin_featured_03_maven_stay_or_leave_800x450.png")
C = os.path.join(OUT, "linkedin_featured_QA_contact_sheet.png")
D_ = os.path.join(OUT, "linkedin_featured_03_mobile_legibility_preview.png")

d = new_doc()
header_band(d, "Internal Operations — Not Participant-Facing",
            "LinkedIn Featured Image — QA Note",
            "September 16, 2026 Maven Lightning Lesson  ·  CANDIDATE  ·  " + STAMP)
body(d, f"PRODUCTION REVISION STAMP — {STAMP}", bold=True, color=RED, size=10.5)

hr(d); h1(d, "Read this first — a gap in the brief's premise")
body(d, "The brief asks for the same generator and visual system used for four existing "
        "LinkedIn Featured images, shown in an approved QA contact sheet. THOSE FOUR IMAGES, "
        "THAT CONTACT SHEET AND THAT GENERATOR ARE NOT IN THIS REPOSITORY OR ANYWHERE IN ITS "
        "GIT HISTORY. Searched by filename, by content string and across every commit: zero "
        "matches for linkedin_featured, Executive Briefing, Organizational Scan, 1600x900 or "
        "any contact sheet.", bold=True, color=RED, size=9.8)
body(d, "So this image could not be matched to them, and this note does not claim it was. It "
        "was built instead from the sources that ARE here: the site's brand palette "
        "(#0F2347 navy, #F5F0E8 cream, #C9A84C gold, #C1440E rust, verified in the site CSS) "
        "and the three OFL typefaces used across the deck family — Cormorant Garamond, DM Sans "
        "and Montserrat — following the written design direction in the brief. Send the four "
        "images and I will align this one to them and rebuild.", size=9.8)

hr(d); h1(d, "Confirmations requested in the brief")
tidy(add_two_col_table(d, [
 ("Exact dimensions",
  f"linkedin_featured_03_maven_stay_or_leave_1600x900.png measures "
  f"{Image.open(A).size[0]}x{Image.open(A).size[1]}. "
  f"linkedin_featured_03_maven_stay_or_leave_800x450.png measures "
  f"{Image.open(B).size[0]}x{Image.open(B).size[1]}. Both PNG, RGB, no alpha."),
 ("All copy matches the brief",
  "Eyebrow FREE LIVE SESSION. Headline STAY OR LEAVE / YOUR JOB? Secondary line LIVE CAREER "
  "GROWTH ASSESSMENT. Supporting copy verbatim. Card: September 16, 2026 / 6:00 PM CT / "
  "60 MINUTES · FREE. Footer A CAPABILITY FORMATION LIVE SESSION. Every string was compared "
  "character for character against the brief. The retired stalling title and the paid-workshop "
  "title appear nowhere, and nothing describes this as a course, a paid workshop, or promises "
  "to tell anyone whether to quit."),
 ("Public link",
  f"{LINK} — carried in this note and in the filename convention. It is deliberately NOT "
  "burned into the artwork: a URL set small enough to fit would be illegible at Featured "
  "thumbnail size, and LinkedIn takes the destination as a field on the Featured item."),
 ("September 2 asset preserved",
  "No file named for the September 2 Maven session exists in this repository, so none could be "
  "overwritten or deleted. The new asset carries its own distinct filename and was written to "
  "a new directory. Nothing was renamed."),
 ("No other Featured assets modified",
  "The Executive Briefing, Organizational Scan and Field Kit images are absent from the "
  "repository, so nothing of theirs was touched. Version control shows only new files under "
  "scratchpad/linkedin-featured/ and the delivered assets directory."),
 ("Thumbnail legibility",
  "The exported PNG was downsampled to 560, 400, 320 and 240 px wide and inspected. The "
  "headline, September 16, 2026, 6:00 PM CT and 60 MINUTES · FREE all hold at 320px, the "
  "width LinkedIn uses for a Featured thumbnail. See the mobile legibility preview."),
], widths=(1.9, 4.8), header=("Item", "Confirmed")))

hr(d); h1(d, "The optional card line was excluded, deliberately")
body(d, "The brief allows “50-minute guided assessment + 10-minute Q&A” only if it does not "
        "compromise hierarchy, spacing or mobile legibility. It was measured and left out.",
     bold=True, size=9.8)
body(d, "Width was never the problem: at 16px it sets to 362pt inside a 376pt card column, so "
        "it fits on one line. Legibility is the problem. A Featured thumbnail renders about "
        "320px wide, one fifth of this canvas, which puts that line at roughly 3px on screen — "
        "a grey smudge under the event details it is meant to support. Including it also "
        "pushed the card taller than the headline block it sits beside. It belongs in the "
        "Featured item's description text, where it costs nothing and is fully readable.",
     size=9.8)

hr(d); h1(d, "Checks run on the exported PNG, not on the source layout")
rows = [("Exported file is 1600x900", "PASS", "Read back from the PNG."),
        ("Exported file is 800x450", "PASS", "Read back from the PNG."),
        ("No ink in the gutter between column and event card", "PASS",
         "Pixels sampled across the full gutter height: clear. The headline is auto-fitted to "
         "the column — 116pt here — so it cannot reach the card whatever the copy says."),
        ("Outer margins clear on all four edges", "PASS",
         "No ink inside the 104px margin on any edge."),
        ("Event card sits inside the canvas", "PASS", "1028,283 to 1496,582."),
        ("Headline is the dominant element", "PASS",
         "116pt against 25pt for the secondary line and 23pt for supporting copy."),
        ("Secondary line explains without competing", "PASS",
         "LIVE CAREER GROWTH ASSESSMENT is set at 25pt tracked caps, a fifth of the headline."),
        ("No new colours, fonts, icons or devices", "PASS",
         "Four brand colours plus two neutrals from the same palette; three existing "
         "typefaces; no gradient, icon, mockup, stock image or generated person."),
        ("Supporting copy breaks cleanly", "PASS",
         "Two lines, wrapped on measured width, no orphan word.")]
tidy(gate_table(d, [(i + 1, a, b, c) for i, (a, b, c) in enumerate(rows)],
                widths=(0.32, 2.5, 0.62, 3.46)))

hr(d); h1(d, "Files")
tidy(add_two_col_table(d, [
 ("1600x900 PNG", f"SHA-256 {sha(A)}"),
 ("800x450 PNG", f"SHA-256 {sha(B)}"),
 ("QA contact sheet", "Position 3 carries the new image. Positions 1, 2 and 4 are rendered as "
  "labelled empty slots because those files are not in the repository. Drop them into "
  "scratchpad/linkedin-featured/siblings/ and re-run build_qa_assets.py to complete the sheet."),
 ("Mobile legibility preview", "Four true display widths, 560 down to 240px."),
], widths=(1.9, 4.8), header=("Output", "Detail")))

hr(d); h1(d, "Status")
body(d, "CANDIDATE, NOT FINAL. The exported PNGs, the contact sheet and the mobile preview "
        "have all been visually inspected and the geometry checks were run against the "
        "exported pixels. What is NOT verified is consistency with the four existing Featured "
        "images, because they are not available here. That is the one gate between this and "
        "FINAL.", bold=True, color=RED, size=9.8)

hr(d)
body(d, "LINKEDIN FEATURED — SEPTEMBER 16, 2026 MAVEN LIGHTNING LESSON  ·  INTERNAL ONLY  ·  "
        + STAMP, italic=True, size=8, color=GREY, space_after=0)
p = os.path.join(OUT, "LinkedIn_Featured_Sept16_QA_Note.docx")
d.save(p)
print("Saved", os.path.basename(p))
