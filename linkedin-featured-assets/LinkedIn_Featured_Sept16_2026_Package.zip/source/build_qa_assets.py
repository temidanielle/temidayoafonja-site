# -*- coding: utf-8 -*-
"""QA contact sheet, mobile-scale legibility preview, and geometry checks.

The three sibling Featured images (Executive Briefing, Organizational Scan,
Field Kit) are not present in this repository or its git history, so the
contact sheet renders them as labelled empty slots rather than inventing
artwork. Drop the real files into ./siblings/ and re-run to fill them in.
"""
import os, glob
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "out")
SIB = os.path.join(HERE, "siblings")
os.makedirs(SIB, exist_ok=True)

NAVY  = (15, 35, 71)
CREAM = (245, 240, 232)
GOLD  = (201, 168, 76)
RUST  = (193, 68, 14)
MUTED = (90, 107, 132)
PALE  = (233, 237, 243)
WHITE = (255, 255, 255)

NEW = os.path.join(OUT, "linkedin_featured_03_maven_stay_or_leave_1600x900.png")

def F(n, s): return ImageFont.truetype(os.path.join(HERE, n), s)
LB, SB, SR = "Montserrat-Bold.ttf", "DMSans-Bold.ttf", "DMSans-Regular.ttf"

def tracked(d, x, y, s, font, fill, ls=0.0):
    for ch in s:
        d.text((x, y), ch, font=font, fill=fill, anchor="la")
        x += d.textlength(ch, font=font) + ls

SLOTS = [
    ("01", "Executive Briefing", None),
    ("02", "Organizational Scan", None),
    ("03", "Maven — Stay or Leave Your Job?", NEW),
    ("04", "Capability Formation Field Kit", None),
]

def find_sibling(label):
    key = label.lower().split("—")[0].strip().replace(" ", "_")
    hits = glob.glob(os.path.join(SIB, f"*{key.split('_')[0]}*"))
    return hits[0] if hits else None

def contact_sheet():
    TW_, TH = 640, 360                      # thumb cell
    GAP, MX, TOP = 44, 64, 168
    W = MX * 2 + TW_ * 2 + GAP
    H = TOP + (TH + 96) * 2 + 64
    img = Image.new("RGB", (W, H), CREAM)
    d = ImageDraw.Draw(img)

    tracked(d, MX, 62, "QA CONTACT SHEET", F(LB, 22), GOLD, ls=6)
    d.text((MX, 100), "LinkedIn Featured — four positions", font=F(SB, 30),
           fill=NAVY, anchor="la")
    d.rectangle([MX, 148, MX + 78, 152], fill=RUST)

    for i, (num, label, path) in enumerate(SLOTS):
        cx = MX + (i % 2) * (TW_ + GAP)
        cy = TOP + (i // 2) * (TH + 96)
        src = path if (path and os.path.exists(path)) else find_sibling(label)
        if src and os.path.exists(src):
            th = Image.open(src).convert("RGB").resize((TW_, TH), Image.LANCZOS)
            img.paste(th, (cx, cy))
            d.rectangle([cx, cy, cx + TW_ - 1, cy + TH - 1], outline=(214, 222, 233))
            state = "NEW — this delivery" if path else "existing asset"
            scol = RUST if path else MUTED
        else:
            d.rectangle([cx, cy, cx + TW_ - 1, cy + TH - 1], fill=PALE,
                        outline=(206, 216, 229))
            msg = "NOT IN REPOSITORY"
            f = F(LB, 17)
            wpx = d.textlength(msg, font=f) + 4 * (len(msg) - 1)
            tracked(d, cx + (TW_ - wpx) / 2, cy + TH / 2 - 26, msg, f, MUTED, ls=4)
            f2 = F(SR, 15)
            m2 = "supply the file to complete this sheet"
            d.text((cx + (TW_ - d.textlength(m2, font=f2)) / 2, cy + TH / 2 + 6),
                   m2, font=f2, fill=MUTED, anchor="la")
            state = "absent — not created or modified here"
            scol = MUTED
        tracked(d, cx, cy + TH + 18, num, F(LB, 15), GOLD, ls=3)
        d.text((cx + 34, cy + TH + 16), label, font=F(SB, 18), fill=NAVY, anchor="la")
        d.text((cx, cy + TH + 46), state, font=F(SR, 15), fill=scol, anchor="la")

    d.text((MX, H - 44), "Position 3 is the September 16, 2026 Maven Lightning Lesson. "
           "The other three are unmodified.", font=F(SR, 16), fill=MUTED, anchor="la")
    p = os.path.join(OUT, "linkedin_featured_QA_contact_sheet.png")
    img.save(p); return p, sum(1 for _, _, x in SLOTS if x)

def mobile_preview():
    src = Image.open(NEW).convert("RGB")
    sizes = [(560, "Featured card, desktop"),
             (400, "Featured card, tablet"),
             (320, "Featured thumbnail, mobile"),
             (240, "Smallest observed thumbnail")]
    MX, TOP, GAP = 64, 176, 52
    colw = max(s for s, _ in sizes)
    H = TOP + sum(int(s * 9 / 16) + 62 for s, _ in sizes) + GAP * (len(sizes) - 1) + 40
    W = MX * 2 + colw
    img = Image.new("RGB", (W, H), CREAM)
    d = ImageDraw.Draw(img)
    tracked(d, MX, 62, "MOBILE-SCALE LEGIBILITY PREVIEW", F(LB, 20), GOLD, ls=5)
    d.text((MX, 100), "Rendered at true display widths", font=F(SB, 28), fill=NAVY,
           anchor="la")
    d.rectangle([MX, 148, MX + 78, 152], fill=RUST)

    y = TOP
    for s, label in sizes:
        h = int(s * 9 / 16)
        img.paste(src.resize((s, h), Image.LANCZOS), (MX, y))
        d.rectangle([MX, y, MX + s - 1, y + h - 1], outline=(214, 222, 233))
        d.text((MX, y + h + 14), f"{s} x {h} px  ·  {label}", font=F(SR, 16),
               fill=MUTED, anchor="la")
        y += h + 62 + GAP
    p = os.path.join(OUT, "linkedin_featured_03_mobile_legibility_preview.png")
    img.save(p); return p

def geometry_checks():
    """Ink-based checks on the exported PNG, not on the source layout."""
    import build_featured as bf
    im = Image.open(NEW).convert("RGB")
    px = im.load()
    W, H = im.size
    checks = []

    def ink_bbox(x0, y0, x1, y1, bg):
        xs, ys = [], []
        for y in range(y0, y1, 2):
            for x in range(x0, x1, 2):
                if sum(abs(a - b) for a, b in zip(px[x, y], bg)) > 40:
                    xs.append(x); ys.append(y)
        return (min(xs), min(ys), max(xs), max(ys)) if xs else None

    # nothing may cross into the gutter between column and card
    g = ink_bbox(bf.COL_R, 0, bf.CARD_X, H, CREAM)
    checks.append(("No ink in the gutter between column and card", g is None,
                   "clear" if g is None else f"ink at {g}"))
    # margins honoured on all four edges
    edges = {
        "left":   ink_bbox(0, 0, bf.M - 6, H, CREAM),
        "right":  ink_bbox(W - bf.M + 6, 0, W, H, CREAM),
        "top":    ink_bbox(0, 0, W, 60, CREAM),
        "bottom": ink_bbox(0, H - 60, W, H, CREAM),
    }
    bad = [k for k, v in edges.items() if v is not None]
    checks.append(("Outer margins clear on all four edges", not bad,
                   "clear" if not bad else f"ink in {bad}"))
    # card fully inside the canvas
    x0, y0, x1, y1 = 1028, 283, 1496, 582
    checks.append(("Event card sits inside the canvas",
                   0 < x0 and x1 < W and 0 < y0 and y1 < H,
                   f"card {x0},{y0}-{x1},{y1} in {W}x{H}"))
    checks.append(("Exported 1600x900", im.size == (1600, 900), f"{im.size}"))
    small = Image.open(os.path.join(
        OUT, "linkedin_featured_03_maven_stay_or_leave_800x450.png"))
    checks.append(("Exported 800x450", small.size == (800, 450), f"{small.size}"))
    return checks

if __name__ == "__main__":
    cs, n = contact_sheet()
    mp = mobile_preview()
    print("contact sheet ->", os.path.basename(cs), f"({n} of 4 slots filled)")
    print("mobile preview ->", os.path.basename(mp))
    print()
    for label, ok, detail in geometry_checks():
        print(f"  [{'PASS' if ok else 'FAIL'}] {label:<46} {detail}")
