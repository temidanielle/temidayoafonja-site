==============================================================================
CAPABILITY FORMATION  |  VIDEOS 4 TO 14  |  COMPLETE PRODUCTION PACKAGES
Part 2 Of 2 Videos 10-14
==============================================================================

The full set is larger than a single shareable archive, so it ships as two
parts. This is part 2 of 2 videos 10-14. The two parts together hold all eleven videos and
nothing is duplicated between them except the two documents below, which are
in both so either part can be read on its own.

  V04-V14_PRODUCTION_APPROACH_FOR_EDITORIAL_ADVISOR.docx
      How these eleven packages were built, what was reused rather than
      made, and the seven questions that are open and need an editorial
      decision. This is the document to hand to the advisor.

  V04-V14_COMPLETE_PRODUCTION_PACKAGE_MANIFEST.docx
      Every required artifact for every one of the eleven videos, listed as
      present or missing. 31 artifacts per video, 341 slots, none missing.

------------------------------------------------------------------------------
IN THIS PART
------------------------------------------------------------------------------

  V10   Your First 90 Days in a New Job: What Really Matters
        VIDEO_10_COMPLETE_PRODUCTION_PACKAGE/
  V11   What to Do When Your New Job Isn’t the Job You Accepted
        VIDEO_11_COMPLETE_PRODUCTION_PACKAGE/
  V12   How to Turn One Accomplishment Into Proof in 10 Minutes
        VIDEO_12_COMPLETE_PRODUCTION_PACKAGE/
  V13   Which Parts of Your Experience Actually Transfer to Another Industry?
        VIDEO_13_COMPLETE_PRODUCTION_PACKAGE/
  V14   I Read Two Similar Jobs. They Wanted Different Proof
        VIDEO_14_COMPLETE_PRODUCTION_PACKAGE/

------------------------------------------------------------------------------
STATUS
------------------------------------------------------------------------------

  V4 to V11   REOPENED for the limited editorial refresh described in the
              September 24 audit. The packages here are the base source.
              They are not superseded until revised masters are approved.

  V12 to V14  LOCKED. Not part of the refresh and not to be modified.

  Each video folder holds seven sub-folders: 01 recording, 02 visuals,
  03 editor, 04 Shorts, 05 publishing, 06 viewer application, and
  07 evidence and QA.

  Every recording master and thought-block copy in here is byte for byte
  identical to the locked V1 to V14 archive. Verified by checksum, all 22
  of them.

==============================================================================
