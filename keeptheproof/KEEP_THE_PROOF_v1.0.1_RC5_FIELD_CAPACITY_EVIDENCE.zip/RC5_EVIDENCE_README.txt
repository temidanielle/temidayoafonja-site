KEEP THE PROOF - v1.0.1 internal build RC5
Interactive field-capacity correction: evidence
===============================================

WHAT WAS WRONG
--------------
Every fillable field inherited ReportLab's default /MaxLen of 100, so a customer
could type at most 100 characters into fields designed to hold a full narrative
answer (200-300+). The earlier programmatic fill tests set field values through
the PDF API, which does NOT enforce /MaxLen, so they never established whether a
person could actually TYPE the required amount in a viewer. That gap is the
release blocker RC5 corrects.

WHAT RC5 CHANGED (source generators only; no compiled PDF patched)
------------------------------------------------------------------
ktp.py now assigns a deliberate, per-field /MaxLen from a capacity map
(field_specs) keyed to what each field is designed to hold and the acceptance
tests - never a blanket value:

  full narrative / evidence fields : intended 300, /MaxLen 600
  medium narrative / context       : intended 180, /MaxLen 360
  verifier / confidentiality / support : intended 140, /MaxLen 280
  short single-line metadata       : sized per field (kept intentionally short)

/MaxLen is always >= the intended acceptance length, with headroom on scrolling
multiline fields so a real answer is never cut off at the test number. The full
field-by-field map is the RC5 Field-Capacity Manifest (.md and .csv).

NON-DESTRUCTIVE, VERIFIED
------------------------
- Pixel-identical to the approved RC3/RC4 design on every page of both PDFs
  (PyMuPDF 150 dpi, max absolute pixel difference 0). Only interactive-field
  behaviour changed.
- Field names, rectangles, multiline flags, page count, bookmarks, links,
  extracted text and icons are unchanged.
- The RC4 page-37 appearance-clip mitigation is preserved (blank appearance
  streams remain clip-free and balanced).

TESTS
-----
Automated (qa_maxlen.py) - build fails if any hold:
  * a field's /MaxLen < its documented acceptance length
  * a narrative field is left at the ReportLab default of 100
  * a required multiline field is not multiline
  * a stress value at the intended length is truncated after save+reopen
  * field names, rectangles, multiline flags or counts drift from the baseline
  Result: PASS on RC5; the same harness FAILS on the RC4 PDFs (148 findings),
  which is the regression test proving it catches the defect.

Per-field fill -> save -> close -> reopen: all 142 fields hold their full
intended-length value with zero truncation (see manifest, Automated column).

Viewer note: PyMuPDF programmatic fill/save/reopen confirms persistence for
every field. It does NOT simulate keystroke entry, and it does not enforce
/MaxLen at set time; the /MaxLen value in the PDF (verified >= intended for
every field) is what a conformant viewer reads to decide how much a person may
type. TRUE keystroke entry in Adobe Acrobat Reader is a MANUAL RELEASE GATE and
is NOT marked passed here.

PAGE 37 (RC4 correction preserved and re-tested after the field change)
-----------------------------------------------------------------------
The RC4 page-37 test matrix was rerun on the capacity-corrected build - blank
and stress-filled, whole-document and pdfseparate-isolated, annotations on,
Ghostscript -dPrinted, across PyMuPDF 1.28.2, Poppler 24.02.0 and PDFium 153.
Every engine renders page 37 with the content top edge and bounding box within
~1px of each other, filled or blank. Poppler 26.05+ (the reported failing
environment) still could not be installed in this sandbox, so the page-37 fix is
described as: "Targeted mitigation implemented and non-regressive across tested
engines; confirmation on Poppler 26.05+ remains pending." The original root
cause is not called conclusively confirmed until that environment is exercised.

RELEASE GATES (both required before publishing)
-----------------------------------------------
  1. Interactive field-capacity acceptance in Adobe Acrobat Reader (manual).
  2. A successful page-37 render test on Poppler 26.05 or later.

ENGINES
-------
  PyMuPDF 1.28.2 | Poppler 24.02.0 (pdftoppm, pdfseparate) | Ghostscript 10.02.1
  | PDFium 153 (pypdfium2). Poppler 26.05+ unavailable (apt caps at 24.02.0;
  conda-forge / binary hosts blocked by the outbound proxy).

FILES IN THIS PACKAGE
---------------------
  RC5_FIELD_CAPACITY_MANIFEST.csv        every field, prev/new MaxLen, results
  qa_maxlen.txt                          automated capacity QA (PASS)
  qa_multiengine_handbook.txt / _ledger  multi-engine top-edge/bbox QA (PASS)
  CUSTOMER_FILE_HASHES.txt               SHA-256 of customer-facing files
  p37_blank_* / p37_filled_*             page-37 renders, every engine
