KEEP THE PROOF — v1.0.1 internal build RC4
Page-37 PDF compatibility correction: raw render evidence
=========================================================

WHAT THIS DEFECT WAS
--------------------
Independent field QA reported that in the shipped RC3 handbook PDF, page 37
("Full Career Evidence Entry, page two of three") rendered with the top content
clipped or shifted in whole-document Ghostscript 10.02.1 and in Poppler 26.05,
while it rendered cleanly in PyMuPDF, in isolated-page Poppler, and in
Ghostscript with annotations disabled. That last fact — clean once annotations
are off — locates the fault in the AcroForm widget *appearance* layer, not in
the ordinary page content.

ROOT CAUSE
----------
Every blank text-field appearance stream ReportLab emits ends with the standard
variable-text wrapper:

    /Tx BMC
    q
    <x> <y> <w> <h> re
    W
    n
    0 g
    0 G
    Q
    EMC

For a BLANK field nothing is painted between the clip (`W n`) and the `Q`, so
that interior rectangle is a clipping path that clips nothing — a no-op. It is,
however, the only active graphics-state construct living in the widget
annotation appearance layer, and it is exactly the construct a strict or newer
renderer can mis-scope when it composites the annotation layer over page content
during a whole-document render (the isolated-page and annotations-off paths
never exercise it, which is why they stayed clean).

THE FIX (source generation, not a compiled-PDF patch)
-----------------------------------------------------
ktp.py now wraps reportlab.pdfbase.acroform.AcroForm.txAP and strips that no-op
interior clip from blank appearance streams. The marked-content and q/Q pairing
stay balanced; every field name, type, flag, rectangle, MaxLen, border style and
colour is untouched. Because the clip bounds nothing when there is no value to
draw, this changes no visible pixel — it only removes the annotation-layer
construct that the reported failure implicated.

Verified: the rebuilt handbook and ledger are pixel-identical to RC3 on every
page (PyMuPDF, max absolute pixel difference = 0 across all 41 + 12 pages), and
every one of the 25 handbook / 117 ledger field dictionaries is byte-identical
to RC3 except for the removal of the clip operators from the /AP /N stream.

REPRODUCTION IN THIS BUILD ENVIRONMENT
--------------------------------------
The reported top clip did NOT reproduce here in any engine or configuration,
before or after the fix, blank or stress-filled, whole-document or truly
isolated. Engines available in this sandbox:

    PyMuPDF            1.28.2
    Poppler (pdftoppm, pdfseparate)   24.02.0
    Ghostscript        10.02.1
    PDFium (pypdfium2) 153.0.7999.0

Poppler 26.05+ (named in the report) could not be installed here: the OS package
index caps Poppler at 24.02.0 and the conda-forge / micromamba / static-binary
hosts are blocked by the environment's outbound proxy. The exact harness below
is provided so it can be re-run against Poppler 26.05+; on 24.02.0 every page,
including page 37, shows a top-edge and content-bounding-box spread of ~1px
(the antialiasing floor) across all engines.

COMMANDS USED (page 37 shown; the QA harness runs every page)
-------------------------------------------------------------
# whole-document, per engine
gs -q -dNOPAUSE -dBATCH -sDEVICE=png16m -r150 -dFirstPage=37 -dLastPage=37 \
   -dPrinted -sOutputFile=p37_gs.png <pdf>
pdftoppm -r 150 -f 37 -l 37 -png -singlefile <pdf> p37_poppler_wholedoc
python3 -c "import pymupdf; pymupdf.open('<pdf>')[36].get_pixmap(dpi=150).save('p37_pymupdf.png')"
python3 -c "import pypdfium2 as p;d=p.PdfDocument('<pdf>');d.init_forms();d[36].render(scale=150/72).to_pil().save('p37_pdfium.png')"

# TRUE single-page isolation (not a -f/-l window): separate first, then render
pdfseparate -f 37 -l 37 <pdf> sep_%d.pdf
pdftoppm -r 150 -png -singlefile sep_37.pdf p37_poppler_pdfseparate

# full multi-engine QA with top-edge + content-bbox + pdfseparate + PDFium:
python3 build/qa_multiengine.py <pdf> <outdir>

FILES IN THIS PACKAGE
---------------------
p37_blank_pymupdf.png / _ghostscript.png / _poppler_wholedoc.png /
  _poppler_pdfseparate.png / _pdfium.png       — blank page 37, every engine
p37_filled_*                                    — stress-filled + saved + reopened
qa_handbook.txt / qa_ledger.txt                 — full multi-engine QA logs
DELIVERABLE_HASHES.txt                          — SHA-256 of the shipped artifacts
